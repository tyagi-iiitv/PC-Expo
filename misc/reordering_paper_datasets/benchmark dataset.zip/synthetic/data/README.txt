Datasets for the PCP study

The default order of dimensions is used (no particular ordering).

The order of the data records is not randomized. 
The clutter points are always at the end of each datasets.