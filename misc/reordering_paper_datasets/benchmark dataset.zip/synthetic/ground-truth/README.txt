The patterns of the ground truth data have been created with the PCDC tool(*). 
The following folders contain the final ground truth datasets as well as the PCDC config files. 

(*) Sebastian Bremm, Martin Hess, Tatiana von Landesberger, Dieter W. Fellner:
PCDC - On the Highway to Data - A Tool for the Fast Generation of Large Synthetic Data Sets. EuroVA@EuroVis 2012